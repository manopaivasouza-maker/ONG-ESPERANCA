
document.addEventListener('DOMContentLoaded', function(){
  const hb = document.querySelector('.hamburger');
  const nav = document.querySelector('.nav');
  hb && hb.addEventListener('click', ()=>{
    nav.classList.toggle('open');
    if(nav.classList.contains('open')) nav.style.display='flex';
    else nav.style.display='';
  });
  document.querySelectorAll('[data-modal-open]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.modal-backdrop').forEach(b=>b.style.display='flex');
      const id = btn.getAttribute('data-modal-open');
      const modal = document.getElementById(id);
      if(modal) modal.style.display='block';
    });
  });
  document.querySelectorAll('[data-modal-close]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.modal-backdrop').forEach(b=>b.style.display='none');
      document.querySelectorAll('.modal').forEach(m=>m.style.display='none');
    });
  });
  const form = document.getElementById('contactForm');
  const toast = document.getElementById('toast');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      let ok = true;
      ['name','email','message'].forEach(name=>{
        const el = form.querySelector("[name="+name+"]");
        if(!el.value.trim()){ el.closest('.field').classList.add('error'); ok=false; }
        else el.closest('.field').classList.remove('error');
      });
      if(!ok) return;
      if(toast){ toast.style.display='block'; setTimeout(()=>toast.style.display='none',3000); }
      form.reset();
    });
  }
});
